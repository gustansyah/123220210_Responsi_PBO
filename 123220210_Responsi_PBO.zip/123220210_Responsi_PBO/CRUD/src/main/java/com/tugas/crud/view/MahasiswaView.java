/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;





import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;

public class MahasiswaView extends JFrame {
    private JTextField searchField = new JTextField(20);
    private JButton searchButton = new JButton("Cari");
    private JTable mahasiswaTable = new JTable();
    private JButton addButton = new JButton("Tambah Mahasiswa");
    private JButton backButton = new JButton("Kembali");
    private JButton editButton = new JButton("Edit Mahasiswa");
    private JButton deleteButton = new JButton("Hapus Mahasiswa");

    public MahasiswaView() {
        setTitle("Daftar Mahasiswa");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("Cari Nama:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        panel.add(searchPanel);

        JScrollPane scrollPane = new JScrollPane(mahasiswaTable);
        panel.add(scrollPane);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton);
        panel.add(buttonPanel);

        add(panel);
    }

    public String getSearchQuery() {
        return searchField.getText();
    }

    public void setSearchResult(DefaultTableModel model) {
        mahasiswaTable.setModel(model);
    }

    public int getSelectedMahasiswaId() {
        int selectedRow = mahasiswaTable.getSelectedRow();
        if (selectedRow != -1) {
            return (int) mahasiswaTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public void addSearchListener(ActionListener listenForSearchButton) {
        searchButton.addActionListener(listenForSearchButton);
    }

    public void addAddListener(ActionListener listenForAddButton) {
        addButton.addActionListener(listenForAddButton);
    }

    public void addBackListener(ActionListener listenForBackButton) {
        backButton.addActionListener(listenForBackButton);
    }
}