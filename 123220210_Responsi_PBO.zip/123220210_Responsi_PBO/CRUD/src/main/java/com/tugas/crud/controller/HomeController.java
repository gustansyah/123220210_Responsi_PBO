/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;





import com.tugas.crud.view.DosenView;
import com.tugas.crud.view.HomeView;
import com.tugas.crud.view.LoginView;
import com.tugas.crud.view.MahasiswaView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomeController {
    private final HomeView homeView;
    private final String username;

    public HomeController(HomeView homeView, String username) {
        this.homeView = homeView;
        this.username = username;
        this.homeView.addDosenListener(new DosenButtonListener());
        this.homeView.addMahasiswaListener(new MahasiswaButtonListener());
        this.homeView.addLogoutListener(new LogoutButtonListener());
    }

    private class DosenButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            DosenController dosenController = new DosenController();
            dosenController.showDosenView();
        }
    }

    private class MahasiswaButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            MahasiswaController mahasiswaController = new MahasiswaController();
            mahasiswaController.showMahasiswaView();
        }
    }

    private class LogoutButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            homeView.dispose();
            LoginView loginView = new LoginView();
            LoginController loginController = new LoginController(loginView);
            loginView.setVisible(true);
        }
    }
}
