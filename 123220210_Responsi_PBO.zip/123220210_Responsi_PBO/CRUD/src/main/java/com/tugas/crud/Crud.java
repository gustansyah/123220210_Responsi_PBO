/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud;

import com.tugas.crud.controller.DosenController;
import com.tugas.crud.controller.HomeController;
import com.tugas.crud.controller.LoginController;
import com.tugas.crud.controller.MahasiswaController;
import com.tugas.crud.model.DosenDAO;
import com.tugas.crud.model.MahasiswaDAO;
import com.tugas.crud.view.DosenView;
import com.tugas.crud.view.HomeView;
import com.tugas.crud.view.LoginView;
import com.tugas.crud.view.MahasiswaView;

public class Crud {
    public static void main(String[] args) {
        LoginView loginView = new LoginView();
        LoginController loginController = new LoginController(loginView);
        loginView.setVisible(true);
    }
}