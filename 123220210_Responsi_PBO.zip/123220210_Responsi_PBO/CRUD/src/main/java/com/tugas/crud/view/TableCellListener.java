/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;



import javax.swing.*;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;

public class TableCellListener implements CellEditorListener {
    private JTable table;
    private ActionListener actionListener;

    public TableCellListener(JTable table, ActionListener actionListener) {
        this.table = table;
        this.actionListener = actionListener;
    }

    @Override
    public void editingStopped(ChangeEvent e) {
        if (actionListener != null) {
            actionListener.actionPerformed(null);
        }
    }

    @Override
    public void editingCanceled(ChangeEvent e) {
        // No action needed on cancel
    }
}

