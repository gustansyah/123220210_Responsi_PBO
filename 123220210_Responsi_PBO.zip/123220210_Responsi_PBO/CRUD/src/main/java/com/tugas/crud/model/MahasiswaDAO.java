/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MahasiswaDAO {
    private final String url = "jdbc:mysql://localhost:3306/university";
    private final String user = "root";
    private final String password = "";

    public List<Mahasiswa> getAllMahasiswas() {
        List<Mahasiswa> mahasiswas = new ArrayList<>();
        String query = "SELECT * FROM mahasiswa";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Mahasiswa mahasiswa = new Mahasiswa(rs.getInt("id"), rs.getString("nama"), rs.getString("nim"), rs.getString("email"), rs.getString("password"), rs.getString("angkatan"));
                mahasiswas.add(mahasiswa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mahasiswas;
    }

    public void addMahasiswa(Mahasiswa mahasiswa) {
        String query = "INSERT INTO mahasiswa (nama, nim, email, password, angkatan) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, mahasiswa.getNama());
            pstmt.setString(2, mahasiswa.getNim());
            pstmt.setString(3, mahasiswa.getEmail());
            pstmt.setString(4, mahasiswa.getPassword());
            pstmt.setString(5, mahasiswa.getAngkatan());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMahasiswa(Mahasiswa mahasiswa) {
        String query = "UPDATE mahasiswa SET nama = ?, nim = ?, email = ?, password = ?, angkatan = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, mahasiswa.getNama());
            pstmt.setString(2, mahasiswa.getNim());
            pstmt.setString(3, mahasiswa.getEmail());
            pstmt.setString(4, mahasiswa.getPassword());
            pstmt.setString(5, mahasiswa.getAngkatan());
            pstmt.setInt(6, mahasiswa.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMahasiswa(int id) {
        String query = "DELETE FROM mahasiswa WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Mahasiswa> searchMahasiswas(String name) {
        List<Mahasiswa> mahasiswas = new ArrayList<>();
        String query = "SELECT * FROM mahasiswa WHERE nama LIKE ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, "%" + name + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Mahasiswa mahasiswa = new Mahasiswa(rs.getInt("id"), rs.getString("nama"), rs.getString("nim"), rs.getString("email"), rs.getString("password"), rs.getString("angkatan"));
                mahasiswas.add(mahasiswa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mahasiswas;
    }
    
    
}