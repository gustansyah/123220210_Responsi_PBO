/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;



import javax.swing.*;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class MahasiswaFormView extends JFrame {
    private JTextField namaField = new JTextField(20);
    private JTextField nimField = new JTextField(15);
    private JTextField emailField = new JTextField(30);
    private JTextField angkatanField = new JTextField(10);
    private JButton saveButton = new JButton("Simpan");

    public MahasiswaFormView() {
        setTitle("Tambah Mahasiswa");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("Nama:"));
        panel.add(namaField);
        panel.add(new JLabel("NIM:"));
        panel.add(nimField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Angkatan:"));
        panel.add(angkatanField);
        panel.add(saveButton);

        add(panel);
    }

    public String getNama() {
        return namaField.getText();
    }

    public String getNim() {
        return nimField.getText();
    }

    public String getEmail() {
        return emailField.getText();
    }

    public String getAngkatan() {
        return angkatanField.getText();
    }

    public void addSaveListener(ActionListener listenForSaveButton) {
        saveButton.addActionListener(listenForSaveButton);
    }
}
