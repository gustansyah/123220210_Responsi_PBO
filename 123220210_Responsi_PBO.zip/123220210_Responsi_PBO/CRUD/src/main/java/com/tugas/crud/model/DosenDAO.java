/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.model;


import com.tugas.crud.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DosenDAO {
    private final String url = "jdbc:mysql://localhost:3306/university";
    private final String user = "root";
    private final String password = "";

    public List<Dosen> getAllDosens() {
        List<Dosen> dosens = new ArrayList<>();
        String query = "SELECT * FROM dosen";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Dosen dosen = new Dosen(rs.getInt("id"), rs.getString("nama"), rs.getString("no_hp"), rs.getString("email"));
                dosens.add(dosen);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dosens;
    }

    public void addDosen(Dosen dosen) {
        String query = "INSERT INTO dosen (nama, no_hp, email) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, dosen.getNama());
            pstmt.setString(2, dosen.getNoHp());
            pstmt.setString(3, dosen.getEmail());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDosen(Dosen dosen) {
        String query = "UPDATE dosen SET nama = ?, no_hp = ?, email = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, dosen.getNama());
            pstmt.setString(2, dosen.getNoHp());
            pstmt.setString(3, dosen.getEmail());
            pstmt.setInt(4, dosen.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDosen(int id) {
        String query = "DELETE FROM dosen WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Dosen> searchDosens(String name) {
        List<Dosen> dosens = new ArrayList<>();
        String query = "SELECT * FROM dosen WHERE nama LIKE ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, "%" + name + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Dosen dosen = new Dosen(rs.getInt("id"), rs.getString("nama"), rs.getString("no_hp"), rs.getString("email"));
                dosens.add(dosen);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dosens;
    }
}