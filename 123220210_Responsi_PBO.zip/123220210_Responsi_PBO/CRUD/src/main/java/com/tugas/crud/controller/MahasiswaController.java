/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;

import com.tugas.crud.model.MahasiswaDAO;
import com.tugas.crud.model.Mahasiswa;
import com.tugas.crud.view.MahasiswaFormView;
import com.tugas.crud.view.MahasiswaView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class MahasiswaController {
    private MahasiswaView mahasiswaView;
    private MahasiswaFormView mahasiswaFormView;
    private MahasiswaDAO mahasiswaDAO;

    public MahasiswaController() {
    this.mahasiswaDAO = new MahasiswaDAO();
    this.mahasiswaView = new MahasiswaView();
    this.mahasiswaFormView = new MahasiswaFormView();
    this.mahasiswaView.addSearchListener(new SearchButtonListener());
    this.mahasiswaView.addAddListener(new AddButtonListener());
    this.mahasiswaView.addBackListener(new BackButtonListener());
}

public void showMahasiswaView() {
    showMahasiswaData();
    mahasiswaView.setVisible(true);
}

private void showMahasiswaData() {
    List<Mahasiswa> mahasiswas = mahasiswaDAO.getAllMahasiswas();
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID");
    model.addColumn("Nama");
    model.addColumn("NIM");
    model.addColumn("Email");
    model.addColumn("Angkatan");

    for (Mahasiswa mahasiswa : mahasiswas) {
        model.addRow(new Object[]{mahasiswa.getId(), mahasiswa.getNama(), mahasiswa.getNim(), mahasiswa.getEmail(), mahasiswa.getAngkatan()});
    }

    mahasiswaView.setSearchResult(model);
}

private class SearchButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        String searchQuery = mahasiswaView.getSearchQuery();
        List<Mahasiswa> mahasiswas = mahasiswaDAO.searchMahasiswas(searchQuery);
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nama");
        model.addColumn("NIM");
        model.addColumn("Email");
        model.addColumn("Angkatan");

        for (Mahasiswa mahasiswa : mahasiswas) {
            model.addRow(new Object[]{mahasiswa.getId(), mahasiswa.getNama(), mahasiswa.getNim(), mahasiswa.getEmail(), mahasiswa.getAngkatan()});
        }

        mahasiswaView.setSearchResult(model);
    }
}

private class AddButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        mahasiswaFormView.setVisible(true);
    }
}

private class BackButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        mahasiswaView.dispose();
    }
}
}