/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.view;


import javax.swing.*;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class DosenFormView extends JFrame {
    private JTextField namaField = new JTextField(20);
    private JTextField noHpField = new JTextField(15);
    private JTextField emailField = new JTextField(30);
    private JButton saveButton = new JButton("Simpan");

    public DosenFormView() {
        setTitle("Tambah Dosen");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JLabel("Nama:"));
        panel.add(namaField);
        panel.add(new JLabel("No. HP:"));
        panel.add(noHpField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(saveButton);

        add(panel);
    }

    public String getNama() {
        return namaField.getText();
    }

    public String getNoHp() {
        return noHpField.getText();
    }

    public String getEmail() {
        return emailField.getText();
    }

    public void addSaveListener(ActionListener listenForSaveButton) {
        saveButton.addActionListener(listenForSaveButton);
    }
}

