/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;

import com.tugas.crud.model.DosenDAO;
import com.tugas.crud.model.Dosen;
import com.tugas.crud.view.DosenFormView;
import com.tugas.crud.view.DosenView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class DosenController {
    private final DosenDAO dosenDAO;
    private final DosenView dosenView;
    private final DosenFormView dosenFormView;

    public DosenController() {
        this.dosenDAO = new DosenDAO();
        this.dosenView = new DosenView();
        this.dosenFormView = new DosenFormView();
        this.dosenView.addSearchListener(new SearchButtonListener());
        this.dosenView.addAddListener(new AddButtonListener());
        this.dosenView.addBackListener(new BackButtonListener());
    }

    public void showDosenView() {
        showDosenData();
        dosenView.setVisible(true);
    }

    private void showDosenData() {
        List<Dosen> dosens = dosenDAO.getAllDosens();
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nama");
        model.addColumn("No. HP");
        model.addColumn("Email");

        for (Dosen dosen : dosens) {
            model.addRow(new Object[]{dosen.getId(), dosen.getNama(), dosen.getNoHp(), dosen.getEmail()});
        }

        dosenView.setSearchResult(model);
    }
    
    

    private class SearchButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String searchQuery = dosenView.getSearchQuery();
            List<Dosen> dosens = dosenDAO.searchDosens(searchQuery);
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID");
            model.addColumn("Nama");
            model.addColumn("No. HP");
            model.addColumn("Email");

            for (Dosen dosen : dosens) {
                model.addRow(new Object[]{dosen.getId(), dosen.getNama(), dosen.getNoHp(), dosen.getEmail()});
            }

            dosenView.setSearchResult(model);
        }
    }

    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenFormView.setVisible(true);
        }
    }

    private class BackButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dosenView.dispose();
        }
    }
}