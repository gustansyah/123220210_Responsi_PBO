/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tugas.crud.controller;



import com.tugas.crud.model.MahasiswaDAO;
import com.tugas.crud.model.Mahasiswa;
import com.tugas.crud.model.User;
import com.tugas.crud.model.UserDAO;
import com.tugas.crud.view.HomeView;
import com.tugas.crud.view.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginController {
    private final LoginView loginView;
    private final UserDAO userDAO;

    public LoginController(LoginView loginView) {
        this.loginView = loginView;
        this.userDAO = new UserDAO();
        this.loginView.addLoginListener(new LoginButtonListener());
    }

    private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = loginView.getUsername();
            String password = loginView.getPassword();

            if (username.isEmpty() || password.isEmpty()) {
                loginView.showMessage("Username dan password tidak boleh kosong.");
                return;
            }

            User user = userDAO.getUserByUsernameAndPassword(username, password);
            if (user != null) {
                loginView.dispose();
                HomeView homeView = new HomeView(username);
                HomeController homeController = new HomeController(homeView, username);
                homeView.setVisible(true);
            } else {
                loginView.showMessage("Username atau password salah.");
            }
        }
    }
}